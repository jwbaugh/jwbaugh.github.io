# NCSU Subdomain Modeling
# Copyright: North Carolina State University 2012

import os
import sys
import operator
import math
import shutil

class domain(object,):
	def __init__(self,dir,n2oName,f123Name,scaledObject,ts_skip, DT,NSPOOLGE,H0):
		self.dir = dir
		self.fort14 = open(self.dir+"fort.14")
		self.nodes=[]
		self.elements=[]
		self.n2oName = "py.140"
		self.f123Name = str(f123Name)
		self.scaledObject = scaledObject
		self.ts_skip = int(ts_skip)
		self.DT = float(DT)
		self.NSPOOLGE = int(NSPOOLGE)
                self.H0 = float(H0)
		

	def readFort14(self):	
		print "reading fort.14 at ", self.dir

		line1 = self.fort14.readline()
		line2 = self.fort14.readline()
		self.n_ele = int(line2.split()[0])
		self.n_nodes = int(line2.split()[1])

		self.nodes = [None]*(self.n_nodes+1)
		self.elements = [None]*(self.n_ele+1)

		for n in range(self.n_nodes):
			line = self.fort14.readline()
			node = int(line.split()[0])
			x = float(line.split()[1])
			y = float(line.split()[2])
			d = float(line.split()[3])
			self.nodes[node] = [x,y,d]


		for e in range(self.n_ele):
			line = self.fort14.readline()
			ele = int(line.split()[0])
			n1 = int(line.split()[2])
			n2 = int(line.split()[3])
			n3 = int(line.split()[4])
			self.elements[ele] = [n1,n2,n3]

		# Boundaries:
		self.boundaries = []
		line = self.fort14.readline()
		line = self.fort14.readline()
		line = self.fort14.readline()
		self.n_bnodes = int(line.split()[0])
		
		for n in range(self.n_bnodes):
			line = self.fort14.readline()
			self.boundaries.append( int(line.split()[0]) )
			
		


	def readFort80(self):
		self.fort80 = open(self.dir+'fort.80')
		for i in range(14):
			line = self.fort80.readline()
			if line.split()[-1] == "NWLAT":
				break
			if i==3 :
				self.n_ele   = int(line.split()[0])
				self.n_nodes = int(line.split()[1])
			if i==4 :
				self.nprocs = int(line.split()[0])


		#create mapping array between proc and global node numbering:
		self.nodesP2G = [None]*self.nprocs	#initialize 2D mapping array
		self.pnnodes=[None]*self.nprocs # number of nodes for each processor	
		for proc in range(self.nprocs):
			line = self.fort80.readline()
			proc = int(line.split()[0])

			self.pnnodes[proc] = int(line.split()[1])
			self.nodesP2G[proc] = [None]*(self.pnnodes[proc] + 1)

			lines = int(math.ceil(float(self.pnnodes[proc])/9))
			for l in range(lines):
				line = self.fort80.readline()
				try: 
					for i in range(9):
						self.nodesP2G[proc][ l*9+(i+1) ] = int(line.split()[i])
						
				except:
					print "node mapping ok",proc					

		self.fort80.readline()
		for n in range(self.n_nodes):
			self.fort80.readline()
		
		print "done reading 80"
						

	def readN2o(self):
		print "reading new to old nodes at ", self.dir
		self.n2onodes = open(self.dir+self.n2oName)
		self.n2onodes.readline()
		self.n2o = [None]*(self.n_nodes+1)
		for n in range(self.n_nodes):
			line = self.n2onodes.readline()
			new = int(line.split()[0]) 
			old = int(line.split()[1])
			self.n2o[new] = old		



	def readGlobalOutnodes(self):
		globalONFile = open(self.dir+"fort.015")
		self.globalONArray = []
		line = globalONFile.readline()
		line = globalONFile.readline()
		line = globalONFile.readline()
		line = globalONFile.readline()
		line = globalONFile.readline()
		line = globalONFile.readline()
		self.n_outnodes = int(line.split()[0])
		for i in range(self.n_outnodes):
			line = globalONFile.readline()
			self.globalONArray.append( int(line.split()[0]) )


	def createOutnodesArray(self):
		self.poutnodes=[None] * (self.nprocs+1)
		self.n_poutnodes = [0] * (self.nprocs+1)

		for proc in range(self.nprocs):
			self.poutnodes[proc] = []

			for n in range(self.pnnodes[proc]):
				gnode = self.nodesP2G[proc][ n+1 ]
				if gnode in self.globalONArray:
					self.poutnodes[proc].append ( int(n+1) )
					self.n_poutnodes[proc] += 1


	def readWriteOutputs(self):

		self.Elev = [None]*(self.n_nodes+1)
		self.XVel = [None]*(self.n_nodes+1)
		self.YVel = [None]*(self.n_nodes+1)
		self.WD = [None]*(self.n_nodes+1)


		#read unnecesary lines of fort.063
		fort63 = open(self.dir+"fort.063")
		fort63.readline()
		fort63.readline()
		fort63.readline()

		#read unnecesary lines of fort.064
		fort64 = open(self.dir+"fort.064")
		fort64.readline()
		fort64.readline()
		fort64.readline()



		localGlobalOutnodes = [None]*(self.nprocs+1)
		self.nwnodes = [0] * (self.nprocs+1)


		#Open local fort.065 files
		for proc in range(self.nprocs):
			if proc < 10:
				localGlobalOutnodes[proc] = open(self.dir+"PE000"+str(proc)+"/fort.065")
			elif proc > 9 and proc < 100 :
				localGlobalOutnodes[proc] = open(self.dir+"PE00"+str(proc)+"/fort.065")
			elif proc > 99 and proc < 1000 :
				localGlobalOutnodes[proc] = open(self.dir+"PE0"+str(proc)+"/fort.065")
			else:
				localGlobalOutnodes[proc] = open(self.dir+"PE"+str(proc)+"/fort.065")

			
		for proc in range(self.nprocs):
			if self.n_poutnodes[proc] < 2 : 
				pass
			else:		
				line = localGlobalOutnodes[proc].readline()
                        	self.nwnodes[proc] = int(line.split()[0])


		#INITIALIZE NEW FORT.19
		new19file = open(self.scaledObject.dir+"fort.019", 'w')
		new19file.write(str(self.DT*self.ts_skip*self.NSPOOLGE)+'\n')	
		for n in self.scaledObject.boundaries:
			g_node = self.scaledObject.n2o[ int(n) ]
			new19file.write(str(0)+' '+str(0)+' '+str(0)+'\n'+str(0)+'\n')


		ts = 0
		while True:


#DO NOT WRITE (SKIP)
			for i in range(self.ts_skip-1): #skip "self.ts_skip-1" ts

				ts+=1
				#FORT.065 (self.WD) 
				try:
					for proc in range(self.nprocs):
						if self.nwnodes[proc] < 2 : 
							pass
						else:		
							for n in range( self.nwnodes[proc] ):
								localGlobalOutnodes[proc].readline()


				except IndexError:
					print "done reading fort.065 for(skipped) ",proc


				#FORT.63 (self.Elev) 
				try:
					for n in range( self.n_outnodes ):
						fort63.readline()
					fort63.readline()

				except IndexError:
					print "done reading fort.063 (skip)"


				#FORT.64 (self.XVel, self.YVel) 
				try:
					for n in range( self.n_outnodes ):
						fort64.readline()
					fort64.readline()

				except IndexError:
					print "done reading fort.064"
					break


# WRITE	!
			#FORT.065 (self.WD) 
			try:
				for proc in range(self.nprocs):
					if self.nwnodes[proc] < 2 : 
						pass
					else:		
						for n in range( self.nwnodes[proc] ):
							line = localGlobalOutnodes[proc].readline()
                                                        node = int(line.split()[0])
							self.WD[node] =  int(line.split()[1])

			except IndexError:
				print "done reading fort.065 for ",proc


			#FORT.63 (self.Elev) 
			try:
				for n in range( self.n_outnodes ):
					line = fort63.readline()
					node = int(line.split()[0])
					self.Elev[node] = line.split()[1] 

				fort63.readline()

			except IndexError:
				print "done reading fort.063"


			#FORT.64 (self.XVel, self.YVel) 
			try:
				for n in range( self.n_outnodes ):
					line = fort64.readline()
					node = int(line.split()[0])

					self.XVel[node] = line.split()[1]
					self.YVel[node] = line.split()[2] 
				fort64.readline()

			except IndexError:
				print "done reading fort.064"
				break

			ts+=1
			if ts%1000 == 0:	
				print ts


			#WRITE THE TIMESTEP:

			for n in self.scaledObject.boundaries:
				g_node = self.scaledObject.n2o[ int(n) ]
				if float(self.Elev[g_node]) == -99999:
					self.Elev[g_node] = str(-(self.nodes[g_node][2])+self.H0)+'E+00'

				new19file.write(str(self.Elev[g_node])+' '+str(self.XVel[g_node])+' '+str(self.YVel[g_node])+'\n'+str(int(self.WD[g_node]))+'\n')


	# THIS FUNCTION IS FOR SERIAL FULL RUN
	def readWriteOutputsSerial(self):

		self.Elev = [None]*(self.n_nodes+1)
		self.XVel = [None]*(self.n_nodes+1)
		self.YVel = [None]*(self.n_nodes+1)
		self.WD = [None]*(self.n_nodes+1)


		#read unnecesary lines of fort.063
		fort63 = open(self.dir+"fort.063")
		fort63.readline()
		fort63.readline()
		fort63.readline()

		#read unnecesary lines of fort.064
		fort64 = open(self.dir+"fort.064")
		fort64.readline()
		fort64.readline()
		fort64.readline()

		#open fort.065
		fort193 = open(self.dir+"/fort.065")
                line = fort193.readline()
                self.snwnodes = int(line.split()[0])


		#INITIALIZE NEW FORT.19
		new19file = open(self.scaledObject.dir+"fort.019", 'w')
		new19file.write(str(self.DT*self.ts_skip*self.NSPOOLGE)+'\n')	
		for n in self.scaledObject.boundaries:
			g_node = self.scaledObject.n2o[ int(n) ]
			new19file.write(str(0)+' '+str(0)+' '+str(0)+'\n'+str(0)+'\n')

		ts = 0
		while True:

#DO NOT WRITE (SKIP)
			for i in range(self.ts_skip-1): #skip "self.ts_skip-1" ts

				ts+=1
				#FORT.193 (self.WD) 
				try:
					for n in range( self.snwnodes ):
						fort193.readline()


				except IndexError:
					print "done reading fort.065 (skip)"


				#FORT.63 (self.Elev) 
				try:
					for n in range( self.n_outnodes ):
						fort63.readline()
					fort63.readline()

				except IndexError:
					print "done reading fort.063 (skip)"


				#FORT.64 (self.XVel, self.YVel) 
				try:
					for n in range( self.n_outnodes ):
						fort64.readline()
					fort64.readline()

				except IndexError:
					print "done reading fort.064"
					break


# WRITE	!

			#FORT.63 (self.Elev) 
			try:
				for n in range( self.n_outnodes ):
					line63  = fort63.readline()
					line64  = fort64.readline()

					node = int(line63.split()[0])

					self.Elev[node] = line63.split()[1] 
					self.XVel[node] = line64.split()[1]
					self.YVel[node] = line64.split()[2] 


				fort63.readline()
				fort64.readline()

				for n in range( self.snwnodes ):
					line193 = fort193.readline()
					node = int(line193.split()[0])
					self.WD[node] =  int(line193.split()[1])


			except IndexError:
				print "done reading fort.063, fort.064, fort.065"
				break

			ts+=1
			if ts%1000 == 0:	
				print "Timestep", ts


			#WRITE THE TIMESTEP:

			for n in self.scaledObject.boundaries:
				g_node = self.scaledObject.n2o[ int(n) ]
				if float(self.Elev[g_node]) == -99999:
					self.Elev[g_node] = str(-(self.nodes[g_node][2])+self.H0)+'E+00'
	
				new19file.write(str(self.Elev[g_node])+' '+str(self.XVel[g_node])+' '+str(self.YVel[g_node])+'\n'+str(int(self.WD[g_node]))+'\n')

		# ^ THIS FUNCTION IS FOR SERIAL FULL RUN ^
			





def main(p_or_s, originaldir, scaleddir, everyXtimestep, DP, NSPOOLGE,H0):

        scaledN2oName = "py.140"
	if (float(everyXtimestep) % float(NSPOOLGE) == 0):
		ts_skip = int( float(everyXtimestep) / float(NSPOOLGE) )
	else:
		print ""
		print "ERROR: everyXtimestep must be dividable by NSPOOLGE "
		print ""
		quit()

	scaled = domain( scaleddir, scaledN2oName,'',None, 0, 0, 0, H0 )
	scaled.readFort14()
	scaled.readN2o()
		
	original = domain( originaldir,'','',scaled, ts_skip, DP, NSPOOLGE, H0 )
	original.readFort14()
	if str(p_or_s) == "-p":
		original.readFort80()
	original.readGlobalOutnodes()
	if str(p_or_s) == "-p":
		original.createOutnodesArray()
		original.readWriteOutputs()
	elif str(p_or_s) == "-s":
		original.readWriteOutputsSerial()

	

# VARIABLE DEFINITIONS:
# forcing-freq = everyXtimestep: Number of time step at which information must be written to fort.019 file
# DT: Timestep in seconds
# NSPOOLGE: Number of time step at which information is written to fort.063 file

def Usage():
    print ""
    print "Usage:"

    print " for parallel full run: -p"
    print " for serial full run: -s"
    print " [OriginalPath][ScaledPath][forcing-freq][DT][NSPOOLGS][H0]"
    print " NOTE: forcing-freq must be multiple of NSPOOLGS !"
    print ""

if __name__== "__main__":
    if len(sys.argv) == 8:
        main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7])
    else:
        Usage()
