# NCSU Subdomain Modeling
# Copyright: North Carolina State University 2012

import os
import sys
import operator
import math
import shutil

class subdomain(object,):
	def __init__(self,dir,n2oName):
		self.dir = dir
		self.fort14 = open(self.dir+"fort.14")
		self.nodes=[]
		self.elements=[]
		self.n2oName = str(n2oName)


	def readFort14(self):	
		print "reading fort.14 at ", self.dir

		line1 = self.fort14.readline()
		line2 = self.fort14.readline()
		self.n_ele = int(line2.split()[0])
		self.n_nodes = int(line2.split()[1])

		self.nodes = [None]*(self.n_nodes+1)
		self.elements = [None]*(self.n_ele+1)

		for n in range(self.n_nodes):
			line = self.fort14.readline()
			node = int(line.split()[0])
			x = float(line.split()[1])
			y = float(line.split()[2])
			d = float(line.split()[3])
			self.nodes[node] = [x,y,d]


		for e in range(self.n_ele):
			line = self.fort14.readline()
			ele = int(line.split()[0])
			n1 = int(line.split()[2])
			n2 = int(line.split()[3])
			n3 = int(line.split()[4])
			self.elements[ele] = [n1,n2,n3]

		# Boundaries:
		self.boundaries = []
		line = self.fort14.readline()
		line = self.fort14.readline()
		line = self.fort14.readline()
		self.n_bnodes = int(line.split()[0])
		
		for n in range(self.n_bnodes):
			line = self.fort14.readline()
			self.boundaries.append( int(line.split()[0]) )
			
		
	def readN2o(self):
		print "reading new to old nodes at ", self.dir
		self.n2onodes = open(self.dir+self.n2oName)
		self.n2onodes.readline()
		self.n2o = [None]*(self.n_nodes+1)
		for n in range(self.n_nodes):
			line = self.n2onodes.readline()
			new = int(line.split()[0]) 
			old = int(line.split()[1])
			self.n2o[new] = old




def main(typ, fulldir, n_sub):

	print "This script creates fort.015 file for ADCIRC-v50_51 Subdomain Modeling. "
	fullrun = subdomain(fulldir,'py.140')
	fort015 =  open("fort.015", 'w')

	NOUTGS = raw_input("Enter the parameter 'NOUTGS': \n")
	NSPOOLGS = raw_input("Enter the parameter 'NSPOOLGS': \n")
	ncsu_bound_ele = str(0)
	ncsu_bound_vel = str(0)
	ncsu_bound_wd = str(0)
	fort015.write( NOUTGS + "	!NOUTSG" + '\n' )
	fort015.write( NSPOOLGS + "	!NSPOOLGS" + '\n' )
	fort015.write( ncsu_bound_ele + "	!ncsu_bound_ele" + '\n' )
	fort015.write( ncsu_bound_vel + "	!ncsu_bound_vel" + '\n' )
	fort015.write( ncsu_bound_wd + "	!ncsu_bound_wd" + '\n' )

	subdomains = []		
	if typ == "-s" :
		boundariesAll = []
		for i in range(int(n_sub)):
			try:
				print "Enter the directory of subdomain -", str(i+1), "of", str(n_sub),":"
				subdir = raw_input()
				sub = subdomain(subdir,'py.140')
			except IOError:
				print "No such file or directory, please enter a valid subdomain directory:"
				subdir = raw_input()
				sub = subdomain(subdir,'py.140')

			sub.readFort14()
			sub.readN2o()
			for n in range(sub.n_bnodes):
				boundariesAll.append( sub.n2o[ sub.boundaries[n] ] )	
			print "Subdomain",str(i+1), "is done."

		boundariesAll.sort()
		fort015.write( str(len(boundariesAll))+'\n' )
		for n in boundariesAll:
			fort015.write( str(n)+'\n' )

		print "fort.015 file is created."


	elif typ == "-a" :
		fullrun.readFort14()
		fort015.write( str(fullrun.n_nodes)+'\n' )
		for i in range(fullrun.n_nodes):
			fort015.write( str(i+1)+'\n' )
		print "fort.015 file is created."
		


def Usage():
    print ""
    print "Usage:"
    print " Print all nodes :			", sys.argv[0],"-a [Path]"
    print " Print only subd. boundary-nodes:	", sys.argv[0],"-s [FullDomain Path] [Number of Subdomains]"
    print ""

if __name__== "__main__":


	if len(sys.argv) == 4 or len(sys.argv) == 3:
		if str(sys.argv[1]) == "-s" :
			if len(sys.argv) == 4:
				main(sys.argv[1], sys.argv[2], sys.argv[3])
			else:
				Usage()
		elif str(sys.argv[1]) == "-a" :
			if len(sys.argv) == 3:
				main(sys.argv[1], sys.argv[2], "0")	
			else:
				Usage()
		else:
			Usage()
	else:
		Usage()

