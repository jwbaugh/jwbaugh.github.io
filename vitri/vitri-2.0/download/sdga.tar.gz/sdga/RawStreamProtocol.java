/*
 * RawStreamProtocol.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.io.*;

/**
 * A communication protocol that uses the default object
 * serialization provided by Java.  However, this implementation
 * serializes an object to a byte array and then sends it down
 * a raw output stream.  Such an approach appears to avoid some
 * of the caching and other overhead problems associated with
 * the use of object input and output streams.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class RawStreamProtocol extends CommunicationProtocol {

    private InputStream in;
    private OutputStream out;
    private byte[] buffer;

    /**
     * Constructs a RawStreamProtocol over the specified input and
     * output streams and buffer size.
     */
    public RawStreamProtocol(InputStream in, OutputStream out, int buffer_size)
                             throws IOException {
	this.in = in;
	this.out = out;
	buffer = new byte[buffer_size + 1];
    }

    /**
     * Reads and returns an object.
     */
    public Object readObject() throws IOException, ClassNotFoundException {
	int bytes_read = in.read(buffer);
	if (bytes_read == buffer.length)
	    throw new RuntimeException("In RawStreamProtocol.readObject: " +
				       "buffer length exceeded (" +
				       (buffer.length - 1) + ")");
	ByteArrayInputStream bais =
	    new ByteArrayInputStream(buffer, 0, bytes_read);
	ObjectInputStream ois = new ObjectInputStream(bais);
	return ois.readObject();
    }

    /**
     * Writes an object to the underlying stream.
     */
    public void writeObject(Object obj) throws IOException {
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	ObjectOutputStream oos = new ObjectOutputStream(baos);
	oos.writeObject(obj);
	oos.close();
	byte[] b = baos.toByteArray();
	out.write(b);
	out.flush();
    }

    /**
     * Closes the streams associated with this CommunicationProtocol.
     * This method must be called to release any resources associated
     * with the streams.
     */
    public void close() throws IOException {
	in.close();
	out.close();
    }
}
