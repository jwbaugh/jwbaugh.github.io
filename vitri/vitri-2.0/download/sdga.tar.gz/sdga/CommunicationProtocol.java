/*
 * CommunicationProtocol.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.io.*;

/**
 * This class uses the Factory design pattern to set the way in which
 * objects are communicated between clients and servers.  The
 * communication protocol includes two customizable aspects:
 * <ol>
 * <li> the type of communication stream used, e.g., object
 *      streams versus ordinary I/O streams, and
 * <li> the way in which objects are serialized using readObject
 *      and writeObject methods.
 * </ol>
 * If communication protocols are always instantiated using the static
 * create method in this class, users can affect the way all objects
 * are communicated by doing the following:
 * <ol>
 * <li> creating a new class that extends CommunicationProtocol, and
 * <li> modifying CommunicationProtocol.create to call the
 *      constructor of that class.
 * </ol>
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public abstract class CommunicationProtocol {

    /**
     * A factory (in the design pattern sense) for creating a
     * CommunicationProtocol.  Any class that extends this one may
     * by instantiated and returned by this method, thereby
     * dictating the manner in which all objects (that use the
     * CommunicationProtocol class) are serialized.
     */
    public static CommunicationProtocol create(InputStream in,
					       OutputStream out)
	                                throws IOException {

	//return new OsProtocol2(in, out);
	//return new ObjectStreamProtocol(in, out);

	// pick a buffer size here of 10K ... if that turns out not
	// to be enough we can adjust it upward (a runtime error
	// will result)
	return new RawStreamProtocol(in, out, 10240);
    }

    /**
     * Reads and returns an object. The class that implements this
     * interface defines where the object is "read" from.
     */
    public abstract Object readObject() throws java.io.IOException,
					       ClassNotFoundException;

    /**
     * Writes an object to the underlying stream. The class that
     * implements this interface defines how the object is written.
     */
    public abstract void writeObject(Object obj) throws java.io.IOException;

    /**
     * Closes the streams associated with this CommunicationProtocol.
     * This method must be called to release any resources associated
     * with the streams.
     */
    public abstract void close() throws java.io.IOException;
}
