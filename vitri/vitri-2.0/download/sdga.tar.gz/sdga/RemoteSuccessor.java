/*
 * RemoteSuccessor.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.io.Serializable;

/**
 * This class is a simple example of how an object can be
 * evaluated remotely using the task pool implementation.
 * Key requirements of any such class are that it
 * <ul>
 * <li> implement the <tt>Task</tt> interface by
 *      defining an appropriate <tt>runTask</tt> method,
 *      and
 * <li> implement <tt>java.io.Serializable</tt> so that
 *      instances of the class can be communicated over a
 *      network
 * </ul>
 * The task performed by RemoteSuccessor is merely the 
 * numerical successor of value with which it is
 * constructed.  Because the task executes so quickly a
 * small delay is introduced in runTask.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class RemoteSuccessor implements Task, Serializable {
    private int my_value;

    /**
     * Constructs a new RemoteSuccessor with the specified integer
     * input.
     */
    public RemoteSuccessor(int i) {
	my_value = i;
    }

    /**
     * Computes and returns the successor of the integer specifed when
     * this RemoteSuccessor was created.
     */
    public Serializable runTask() {
	try {
	    Thread.sleep(1000);	// add a second to the computation time
	} catch (InterruptedException e) {
	    System.err.println("In RemoteSuccessor.runTask: " + e);
	}
	return new Integer(my_value + 1);
    }

    /**
     * Returns a string representation of this RemoteSuccessor.
     */
    public String toString() {
	return String.valueOf(my_value);
    }
}
