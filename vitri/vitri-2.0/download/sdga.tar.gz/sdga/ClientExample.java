/*
 * ClientExample.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.net.*;
import java.io.*;

/**
 * This class is a simple example of how to use a task pool to
 * compute the successor of integer values.  A set of tasks is
 * created and added to a task pool, after which the results
 * of the computation are "demanded," causing the program to
 * block until those results are available.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class ClientExample {

    public static void main(String args[]) {
	int port = 10013;

	// process command line

	if (args.length == 1) {
	    try {
		port = Integer.parseInt(args[0]);
	    }
	    catch (NumberFormatException e) {
		System.err.println("Port number cannot be parsed: " + args[0]);
		System.exit(1);
	    }
	} else if (args.length > 1) {
	    System.err.println("Usage: java ClientExample [port]");
	    System.exit(1);
	}

	// create pool and a pool manager thread

	Pool p = new Pool(port);
	p.start();

	// create a place to hold task handles
	int N = 5;
	TaskHandle t[] = new TaskHandle[N];

	// add tasks to task pool and keep track of their handles
	for (int i = 0; i < N; i++)
	    t[i] = p.addTask(new RemoteSuccessor(10*i));

	// gather task results
	for (int i = 0; i < N; i++) {
	    t[i].getResult();
	    System.out.println(t[i]);
	}

	p.haltServers();

	System.out.println("All done!");
    }
}
