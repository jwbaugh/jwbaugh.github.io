/*
 * Server.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.net.*;
import java.io.*;
import java.util.Random;
import java.text.DecimalFormat;

/**
 * This class implements an iterative server that processes tasks on
 * a one-at-a-time basis.  A Server must register its interest in
 * acting as such by initiating contact with a client through a socket
 * connection.  Once a connection is established, a Server retrieves a
 * task object from the socket stream via object serialization, and
 * invokes the object's <tt>runTask</tt> method.  The result is
 * then written to the socket stream. A Server continues to read and
 * write task objects until a distinguished object, a ServerTerminator
 * object, is read, at which point the Server object itself is written
 * to the socket stream so that the client may gather server
 * statistics.  The protocol used for object serialization is
 * customizable in the CommunicationProtocol class, which defines the
 * type of socket stream used as well as the approach to serialization
 * with the <tt>readObject</tt> and <tt>writeObject</tt> methods.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class Server implements java.io.Serializable {

    private static final DecimalFormat df2 = new DecimalFormat("00");
    private static final DecimalFormat df3 = new DecimalFormat("0.00");

    /** Client to which this server is connected. */
    private String client;

    /** Name of the machine on which this server is running. */
    private String server;

    /** Port number on which this server communicates with the client. */
    private int port;

    /** Pseudo process ID for this server. */
    private long pid;

    /** Interval of time (in seconds) between attempts to contact client. */
    private int try_connect_interval = 1;

    /** Number of tasks performed by this server. */
    private int number_of_tasks = 0;

    /**
     * The running sum of the total time spent "on" task (index 0)
     * and "off" task (index 1), in milliseconds.  Time spent off
     * task (i.e., in the interval between task executions) is due
     * to communication time both to and from the client, as well
     * as the idle time of this server.
     */
    private long[] sum_time = { 0, 0 };

    /**
     * The current maximum time spent "on" any task (index 0) and
     * between tasks (index 1), in milliseconds.
     */
    private long[] max_time = { 0, 0 };

    /**
     * The current minimum time spent "on" any task (index 0) and
     * between tasks (index 1), in milliseconds.
     */
    private long[] min_time = { Long.MAX_VALUE, Long.MAX_VALUE };

    /**
     * Constructs a new server object with the specified client and
     * server names, and the specified port and process id.
     */
    private Server(String client, String server, int port, long pid) {
	this.client = client;
	this.server = server;
	this.port = port;
	this.pid = pid;
    }

    /**
     * Some bookkeeping for maintaining the current sum, maximum, and
     * minimum times both "on" (index 0) and "off" (index 1) task.
     */
    private void tallyStatistics(int i, long start, long stop) {
	long t = stop - start;
	if (t > max_time[i])
	    max_time[i] = t;
	if (t < min_time[i])
	    min_time[i] = t;
	sum_time[i] += t;
    }

    /**
     * Do some formatting to make execution times readable.  For times
     * less than one second, display in milliseconds.  Otherwise, use
     * the typical hh:mm:ss format.
     */
    private String timeFormat(long millis) {
	if (millis < 1000)
	    return millis + "ms";
	else {
	    long hours = millis / (3600 * 1000);
	    millis -= hours * 3600 * 1000;
	    long minutes = millis / (60 * 1000);
	    millis -= minutes * 60 * 1000;
	    double seconds = millis * 0.001;
	    if (hours > 0)
		return hours + ":" + df2.format(minutes) + ":" +
		    df2.format(seconds);
	    else if (minutes > 0)
		return minutes + ":" + df2.format(seconds);
	    else
		return df3.format(seconds) + "s";
	}
    }
		
    /**
     * Prints the number of tasks performed by this server, as well
     * as the running sum, maximum, and minimum of the time spent
     * "on" task and "off" task.  Time spent off task (i.e., in the
     * interval between task executions) is due to communication time
     * both to and from the client, as well as the idle time of this
     * server.
     */
    public void printStatistics() {
	System.out.println("Server " + server + " [" + pid + "] completed " +
			   number_of_tasks + " tasks");
	System.out.println("  Time on task (sum/max/min): " +
			   timeFormat(sum_time[0]) + " / " +
			   timeFormat(max_time[0]) + " / " +
			   timeFormat(min_time[0]));
	System.out.println("  Other time (sum/max/min): " +
			   timeFormat(sum_time[1]) + " / " +
			   timeFormat(max_time[1]) + " / " +
			   timeFormat(min_time[1]));
    }

    /**
     * Prints exceptions to standard error.
     */
    private void printException(String s, Exception e) {
	System.err.println(s + " In Server.start: server " + server +
			   " [" + pid + "]: " + e);
    }

    /**
     * Begin executing an iterative server that attempts to connect
     * to a specifed client, and after which performs tasks by calling
     * their <tt>runTask</tt> methods.  Processing continues
     * until a <tt>ServerTerminator</tt> object is received from
     * the client, or the connection is closed by the client.
     */
    private void start() {

	try {
	    Socket s = null;

	    while (s == null) {	
		try {
		    s = new Socket(client, port);
		}
		catch (ConnectException e) {
		    try {
			// if we cannot connect immediately, keep trying to
			// connect to client every n seconds
			Thread.sleep(try_connect_interval * 1000);
		    }
		    catch (InterruptedException ie) {
			// someone has deliberately called Thread.interrupt(),
			// so clean up and return from start() by exiting
			printException("(1)", ie);
			System.exit(1);
		    }
		}
		catch (UnknownHostException e) {
		    // if the host is unknown, there's nothing to do but exit
		    printException("(2)", e);
		    System.exit(1);
		}
	    }

	    CommunicationProtocol cp =
		CommunicationProtocol.create(s.getInputStream(),
					     s.getOutputStream());

	    long t1 = 0, t2 = 0;

	    while (true) {
		try {
		    Object obj = cp.readObject();
		    if (obj instanceof ServerTerminator) {
			cp.writeObject(this);
			printStatistics();
			System.exit(0);
		    } else if (obj instanceof Task) {
			Task task_obj = (Task) obj;
			System.out.println("Got " + task_obj);
			t1 = System.currentTimeMillis();
			if (t2 != 0)
			    tallyStatistics(1, t2, t1);
			Object result = task_obj.runTask();
			t2 = System.currentTimeMillis();
			tallyStatistics(0, t1, t2);
			cp.writeObject(result);
			number_of_tasks++;
		    } else {
			System.err.println("In Server.start: server " +
					   server + " [" + pid +
					   "] received a non-Task object: " +
					   obj + " ... ignoring");
		    }
		}
		catch (ClassNotFoundException e) {
		    // thrown by readObject() above: ignoring allows us to
		    // continue reading and processing tasks; nevertheless,
		    // print a message that an unrecognized object type
		    // was encountered
		    printException("(3)", e);
		}
	    }
	}
	catch (EOFException e) {
	    // no more tasks to read, so print statistics and terminate
	    // normally
	    printStatistics();
	    System.exit(0);
	}
	catch (IOException e) {
	    // numerous possible causes for this, view all as fatal
	    printException("(4)", e);
	    System.exit(1);
	}
    }

    public static void main(String args[]) {
	String client = "localhost";
	String server;
	int port = 10013;

	// process command line

	if (args.length == 1)
	    client = args[0];
	else if (args.length == 2) {
	    try {
		port = Integer.parseInt(args[1]);
	    }
	    catch (NumberFormatException e) {
		System.err.println("Port number cannot be parsed: " + args[1]);
		System.exit(1);
	    }
	} else if (args.length > 2) {
	    System.err.println("Usage: java Server [client] [port]");
	    System.exit(1);
	}

	try {
	    server = InetAddress.getLocalHost().getHostName();
	} catch (Exception e) {
	    server = "unknown";
	}

	// Create a "pseudo" process id (just a random number, since
	// Java has no built-in getPID() method) so that multiple server
        // processes on a single machine can be distinguished
	long pid = Math.abs(new Random().nextInt()) % 10000;

	System.out.println("Server " + server + " [" + pid +
			   "] trying client " + client + " on port " + port);

	Server s = new Server(client, server, port, pid);
	s.start();
    }
}
