/*
 * ServerTerminator.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.io.Serializable;

/**
 * This class is simply a type of Task that can be distinguished
 * by a server.  Receipt of one of these "marker" objects from a
 * client is interpreted by a server as a request to halt and report
 * its execution statistics.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class ServerTerminator implements Task, Serializable {

    /**
     * Because ServerTerminator is simply a "marker", its runTask
     * method is ignored; a null value is nevertheless returned
     * since, syntactically, something must be.
     */
    public Serializable runTask() {
	return null;
    }
}
