/*
 * OsProtocol2.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.io.*;

/**
 * A communication protocol that uses the default object
 * serialization provided by Java over object streams
 * for input and output.  Unlike the ObjectStreamProtocol,
 * this protocol creates and destroys a new object stream
 * for every readObject and writeObject method call.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class OsProtocol2 extends CommunicationProtocol {

    InputStream in;
    OutputStream out;

    /**
     * Constructs an Os2Protocol over the specified input and
     * output streams.
     */
    public OsProtocol2(InputStream in, OutputStream out) throws IOException {
	this.in = in;
	this.out = out;
    }

    /**
     * Reads and returns an object.
     */
    public Object readObject() throws IOException, ClassNotFoundException {
	ObjectInputStream ois = new ObjectInputStream(in);
	return ois.readObject();
    }

    /**
     * Writes an object to the underlying stream.
     */
    public void writeObject(Object obj) throws IOException {
	ObjectOutputStream oos = new ObjectOutputStream(out);
	oos.writeObject(obj);
	oos.flush();
    }

    /**
     * Closes the streams associated with this CommunicationProtocol.
     * This method must be called to release any resources associated
     * with the streams.
     */
    public void close() throws IOException {
	in.close();
	out.close();
    }
}
