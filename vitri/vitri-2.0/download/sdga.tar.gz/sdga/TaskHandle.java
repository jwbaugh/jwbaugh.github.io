/*
 * TaskHandle.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * This class is used as a wrapper around a task to maintain
 * information about its evaluation status, result, and server
 * on which the task is ultimately performed.  There is typically
 * no reason for users to instantiate this class directly.  Rather,
 * a TaskHandle is automatically created for a task when it is
 * added to a task pool; the new TaskHandle, which is returned from
 * that operation, acts as a handle through which users can retrieve
 * information about their tasks.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class TaskHandle {

    /**
     * A class variable that allows a unique ID to be assigned to
     * each TaskHandle object.
     */
    private static int id_counter = 0;

    /** The ID associated with this TaskHandle. */
    private int id;

    /** The task associated with this TaskHandle. */
    private Task task;

    /** A place to hold the result of calling the runTask method. */
    private Object result;

    /** Set to true when the result is available. */
    private boolean is_ready = false;

    /** Server on which the task is performed. */
    private String server;

    /**
     * Constructs a new TaskHandle for the specified task and assigns
     * it a unique ID.
     */
    public TaskHandle(Task t) {
	id = id_counter++;
	task = t;
    }

    /**
     * Returns the ID of this TaskHandle.
     */
    public int getID() {
	return id;
    }

    /**
     * Returns true if the result of the task associated with
     * this TaskHandle is available; this method immediately
     * returns without blocking.
     */
    public synchronized boolean ready() {
	return is_ready;
    }

    /**
     * Returns the task associated with this TaskHandle.
     */
    public Task getTask() {
	return task;
    }

    /**
     * Returns the result of the task associated with this TaskHandle;
     * this method blocks until the result is available.
     */
    public synchronized Object getResult() {
	while (!is_ready) {
	    try {
		wait();
	    } catch (InterruptedException e) {
		System.err.println("In TaskHandle.getResult: " + e);
	    }
	}
	return result;
    }

    /**
     * Associates the specified result and server with this
     * TaskHandle.
     */
    public synchronized void putResult(Object result, String server) {
	this.result = result;
	is_ready = true;
	this.server = server;
	notify();
    }

    /**
     * Returns a string representation of this TaskHandle.
     */
    public synchronized String toString() {
	String s = "[Task id: " + id + " task: " + task;
	if (is_ready)
	    return s + " result: " + result + " server: " + server + "]";
	else
	    return s + " ready: false]";
    }
}
