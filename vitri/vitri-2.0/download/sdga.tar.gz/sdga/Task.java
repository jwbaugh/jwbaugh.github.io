/*
 * Task.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.io.Serializable;

/**
 * The Task interface should be implemented by any class whose
 * instances are intended to be evaluated remotely using a task pool.
 * The class must define a method of no arguments, called runTask,
 * that returns a Serializable object.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public interface Task {

    /**
     * When an object implementing interface Task is used to
     * perform a task, adding the object to a task pool causes it
     * to be sent to a remote server, where its runTask method is
     * invoked and its result returned. <p>
     *
     * The general contract of the method run is that it may take
     * any action whatsoever.
     */
    Serializable runTask();
}
