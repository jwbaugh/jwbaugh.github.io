/*
 * DistributedGA.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.util.*;

/**
 * This class implements a distributed genetic algorithm that begins
 * with an initial population, and then iteratively (a) selects a
 * mating pool, (b) produces offspring by pairing members of the pool
 * and performing crossover, and (c) mutates each of the offspring
 * to produce a new generation.  Termination of this iterative
 * process is based on two limits: a specified number of generations,
 * and a specified number of generations without improvement in
 * the fittest organism.  An incumbent organism -- the fittest seen
 * at any point in the computation -- is maintained and is made
 * available to the selection operation (implemented by a given
 * population) for implementing an elitism policy.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class DistributedGA extends GeneticAlgorithm {

    Pool pool;
    int port;

    /**
     * Constructs a distributed genetic algorithm with the specified
     * initial population.
     */
    public DistributedGA(Population pop, int port) {
	super(pop);
	this.port = port;
    }

    public void remoteEvaluate(Population p) {
	List ls = new ArrayList(p.size());
	for (Iterator i = p.iterator(); i.hasNext(); ) {
	    Organism org = (Organism) i.next();
	    ls.add(pool.addTask(new RemoteOrganism(org)));
	}
	for (Iterator i = ls.iterator(); i.hasNext(); ) {
	    TaskHandle t = (TaskHandle) i.next();
	    Organism org =
		(Organism) ((RemoteOrganism) t.getTask()).getOrganism();
	    Fitness f = (Fitness) t.getResult();
	    org.setFitnessObject(f);
	}
    }

    /**
     * Performs a run of this genetic algorithm, returning the fittest
     * organism after the specified number of generations, or after no
     * improvement is made for the specified number of generations.
     */
    public Organism run(int max_generations,
			int max_generations_wo_improvement) {

	pool = new Pool(port);
	pool.start();

	// Define the initial population
	Population p = population;

	remoteEvaluate(p);

	Organism incumbent = p.getFittestOrganism();

	int ngwi = 0;		// number of generations without improvement

	for (int i = generation_number + 1; i <= max_generations &&
		 ngwi < max_generations_wo_improvement; i++) {

	    generation_number = i;
	    Population p_new = p.select(incumbent);
	    p_new.crossover();
	    p_new.mutate();

	    remoteEvaluate(p_new);

	    // incumbent.unsetFitness(); // force re-evaluation

	    Organism current_fittest = p_new.getFittestOrganism();
	    if (current_fittest.getFitness() > incumbent.getFitness()) {
		ngwi = 0;
		incumbent = current_fittest;
	    } else {
		ngwi++;
	    }

	    if (print_level > 1) {
		System.out.println("---- Generation " + i + " ----");
		System.out.println("Incumbent organism:\n  " + incumbent);
		System.out.println(p_new);
	    }
	    p = p_new;
	}

	if (print_level > 0) {
	    System.out.println("---- Final Solution ----");
	    System.out.println("Organism:\n  " + incumbent);
	    System.out.println("Number of generations: " + generation_number);
	    System.out.println("Evaluation count: " +
			       Organism.getEvaluationCount());
	}

	population = p;

	pool.haltServers();

	System.out.println("All done!");


	return incumbent;
    }
}
