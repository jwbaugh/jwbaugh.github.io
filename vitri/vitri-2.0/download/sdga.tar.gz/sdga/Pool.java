/*
 * Pool.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.net.*;
import java.io.*;
import java.util.*;

/**
 * This class implements a centralized task pool that is placed between
 * a program (the client) that generates tasks to be performed, and a
 * set of servers that are available to perform those tasks.  Each
 * server repeatedly requests a task, performs it, and returns the
 * result.  For problems consisting of multiple, virtually independent
 * tasks (so-called "embarassingly" parallel problems), a task pool
 * may be an effective approach for balancing loads among servers.
 * Dynamic load balancing is achieved since faster servers request
 * more tasks than slower ones and thereby avoid the idling that
 * results from static scheduling. <p>
 *
 * The pool is managed as a first-in, first-out queue of tasks to be
 * performed, with a separate thread of control (a so-called "manager"
 * thread) that listens on a network port for connections.  The
 * program placing tasks in the pool is considered a client in the
 * sense that it sets the agenda of tasks to be performed.  However,
 * the traditional roles of client and server are swapped, since
 * contact is initiated by servers, who register their readiness to
 * perform tasks for the specified client. <p>
 *
 * The implementation is robust in the presence of both network
 * and server failures.  When a connection to a server goes down,
 * the task it was performing is returned to (the front of) the
 * task pool for subsequent allocation to a different server.
 * The following events can be handled at any time during
 * program execution with a task pool:
 * <ul>
 * <li> a server process may be killed since its task is simply
 *      returned to the pool, and
 * <li> a server process may be started (or restarted) in the
 *      middle of program execution and begin participating.
 * </ul>
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class Pool {

    /**
     * This thread is responsible for listening on the specified
     * port for socket connections from servers.  Once a connection
     * is established, a separate ConnectThread is forked to handle
     * I/O on the new server connection.
     */
    private static class ManagerThread extends Thread {
	int port;
	Pool p;

	private ManagerThread(int pool_port, Pool task_pool) {
	    port = pool_port;
	    p = task_pool;
	}

	public void run() {
	    ServerSocket s;
	    Socket connection;

	    try {
		s = new ServerSocket(port);
		String client = InetAddress.getLocalHost().getHostName();
		System.out.println("Client " + client + " listening on port " +
				   s.getLocalPort());
		while (true) {
		    connection = s.accept();
		    new ConnectThread(connection, p).start();
		}
	    }
	    catch (IOException e) {
		System.err.println("In Pool.ManagerThread: " + e);
	    }
	}
    }

    /**
     * This thread handles exclusively the I/O on a socket connection
     * to a particular server.  A number of exceptions are possible;
     * their origin and resolution in this thread are documented in
     * the code.  The exceptions are also numbered to make it easier
     * to track down problems when they do arise.
     */
    private static class ConnectThread extends Thread {
	Socket s;
	Pool p;

	private ConnectThread(Socket connect_socket, Pool task_pool) {
	    s = connect_socket;
	    p = task_pool;
	}

	public void run() {
	    String server = s.getInetAddress().getHostName();
	    TaskHandle t = null;

	    System.out.println("In Pool.ConnectThread: server " + server +
			       " connected");
	    p.addServer(server);

	    CommunicationProtocol cp = null;

	    try {
		cp = CommunicationProtocol.create(s.getInputStream(),
						  s.getOutputStream());
	    }
	    catch (IOException e) {
		System.err.println("(1) In Pool.ConnectThread: server " +
				   server + ": " + e);
		p.removeServer(server);
		return;
	    }

	    while ((t = p.getTaskHandle()) != null) {
		try {
		    cp.writeObject(t.getTask());
		    Object obj = cp.readObject();
		    t.putResult(obj, server);
		}
		catch (ClassNotFoundException e) {
		    // thrown by readObject() above: if an unrecognized
		    // object type is returned we still need to associate
		    // a result with the given task.  Report the problem,
		    // but keep processing tasks
		    t.putResult("unknown", server);
		    System.err.println("(2) In Pool.ConnectThread: server " +
				       server + ": " + e);
		}
		catch (EOFException e) {
		    System.err.println("(3) In Pool.ConnectThread: server " +
				       server + " is down\n" + "  returning " +
				       t + " to task pool");
		    p.removeServer(server);
		    p.returnToFront(t);
		    return;
		}
		catch (IOException e) {
		    // thrown by writeObject() or readObject() above: report
		    // the problem and put the task taken back in the pool,
		    // but keep processing tasks
		    System.err.println("(4) In Pool.ConnectThread: server " +
				       server + ": " + e);
		    p.returnToFront(t);
		}
	    }

	    try {
		cp.close();
	    }
	    catch (IOException e) {
		System.err.println("(5) In Pool.ConnectThread: server " +
				   server + " while closing: " + e);
	    }
	    
	    p.removeServer(server);
	}
    }

    /**
     * Keep track of the thread that's listening for socket connections.
     */
    private ManagerThread manager;

    /**
     * The queue of tasks that are awaiting service.  Manage in a
     * first-in, first-out discipline.
     */
    private List waiting = new ArrayList();
 
    /**
     * Maintain the names (Strings, as returned by the getHostName
     * method) of the servers currently connected to this task pool.
     */
    private List servers = new ArrayList();

    /**
     * Constructs a new, empty task pool; a manager thread object
     * is associated with the pool, which listens on the specified
     * port once activated by the <tt>Pool.start</tt> method.
     */
    public Pool(int pool_port) {
	manager = new ManagerThread(pool_port, this);
	// don't prevent the JVM from exiting just because a pool
	// manager happens to be running:
	manager.setDaemon(true);
    }

    /**
     * Causes the manager thread for this task pool to begin listening
     * for network connections from servers.  Once started, the
     * manager thread continues to run until all user threads have
     * terminated.
     */
    public void start() {
	manager.start();
    }

    /**
     * Adds the specified task to this task pool and returns a
     * TaskHandle instance, which acts as a handle for the state of
     * the task as it undergoes execution.  For instance, a call to
     * <tt>getResult</tt> on the TaskHandle returned by this
     * method blocks until the runTask method on the task has been
     * performed and then returns its result.
     */
    public synchronized TaskHandle addTask(Task t) {
	TaskHandle handle = new TaskHandle(t);
	waiting.add(handle);
	notify();
	return handle;
    }

    /**
     * Places the specified task in front of other tasks in this task
     * pool.  This method is typically used when a fetched task was
     * unable to complete because of a server or connection failure.
     */
    private synchronized void returnToFront(TaskHandle handle) {
	waiting.add(0, handle);
    }

    /**
     * Fetches a task from this task pool for execution, removing it
     * from the queue of waiting tasks.
     */
    private synchronized TaskHandle getTaskHandle() {
	while (waiting.isEmpty()) {
	    try {
		wait();
	    } catch (InterruptedException e) {
		System.err.println("In Pool.getTaskHandle: " + e);
	    }
	}
	TaskHandle handle = (TaskHandle) waiting.get(0);
	waiting.remove(0);
	return handle;
    }

    /**
     * Add the specified server name to those connected to this
     * task pool.
     */
    private synchronized void addServer(String server) {
	servers.add(server);
    }

    /**
     * Remove the specified server name from those connected to this
     * task pool.
     */
    private synchronized boolean removeServer(String server) {
	return servers.remove(server);
    }

    /**
     * Returns an iterator over the names of the servers currently
     * connected to this task pool.
     */
    public synchronized Iterator getServers() {
	return servers.iterator();
    }

    /**
     * Returns the current number of servers connected to this task pool.
     */
    public synchronized int numServers() {
	return servers.size();
    }

    /**
     * Prints the names of the servers currently connected to this
     * task pool.
     */
    public synchronized void printServers() {
	System.out.println("Connected servers:");
	for (Iterator i = servers.iterator(); i.hasNext(); ) {
	    String s = (String) i.next();
	    System.out.println("  " + s);
	}
    }

    /**
     * Prints a number n of the specified character to standard output.
     */
    private void printChars(int n, char c) {
	for (int i = 0; i < n; i++)
	    System.out.print(c);
    }

    /**
     * Causes all currently connected servers to halt, and prints
     * execution statistics for each server, which include the total
     * number of tasks performed and the amount of time the server
     * spent both on and off task.  The behavior of this method is
     * undefined if this task pool is non-empty or if servers
     * attempt to connect during its execution.
     */
    public void haltServers() {
	int n = numServers();
	TaskHandle t[] = new TaskHandle[n];
	for (int i = 0; i < n; i++)
	    t[i] = addTask(new ServerTerminator());
	printChars(70, '-');
	System.out.println("\nServer Statistics\n");
	for (int i = 0; i < n; i++) {
	    Server s = (Server) t[i].getResult();
	    s.printStatistics();
	}
	printChars(70, '-');
	System.out.println();
    }
}

