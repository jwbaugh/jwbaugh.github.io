/*
 * RemoteOrganism.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.io.Serializable;

/**
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class RemoteOrganism implements Task, Serializable {
    private Organism org;

    /**
     * Constructs a new RemoteOrganism with the specified integer
     * input.
     */
    public RemoteOrganism(Organism org) {
	this.org = org;
    }

    public Organism getOrganism() {
	return org;
    }

    /**
     * Computes and returns the successor of the integer specifed when
     * this RemoteOrganism was created.
     */
    public Serializable runTask() {
	return org.getFitnessObject();
    }

    /**
     * Returns a string representation of this RemoteOrganism.
     */
    public String toString() {
	return org.toString();
    }
}
