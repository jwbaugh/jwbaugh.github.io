/*
 * ObjectStreamProtocol.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.io.*;

/**
 * A communication protocol that uses the default object
 * serialization provided by Java over object streams
 * for input and output.  The writeObject method performs
 * a reset on the output stream to clear the object cache
 * (and thereby keep it from growing out of control).
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class ObjectStreamProtocol extends CommunicationProtocol {

    private ObjectInputStream is;
    private ObjectOutputStream os;

    /**
     * Constructs an ObjectStreamProtocol over the specified
     * input and output streams.
     */
    public ObjectStreamProtocol(InputStream in, OutputStream out)
                                throws IOException {
	// the order of the next two lines is important!!!
	os = new ObjectOutputStream(out);
	is = new ObjectInputStream(in);
    }

    /**
     * Reads and returns an object.
     */
    public Object readObject() throws IOException, ClassNotFoundException {
	return is.readObject();
    }

    /**
     * Writes an object to the underlying stream.
     */
    public void writeObject(Object obj) throws IOException {
	os.reset();
	os.writeObject(obj);
	os.flush();
    }

    /**
     * Closes the streams associated with this CommunicationProtocol.
     * This method must be called to release any resources associated
     * with the streams.
     */
    public void close() throws IOException {
	is.close();
	os.close();
    }
}
