/*
 * SusPopulation.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * This class implements stochastic universal selection.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class SusPopulation extends Population {

    /**
     * A reference to the random number generator defined in the
     * GeneticAlgorithm class (used simply as an abbreviation)
     */
    private static java.util.Random ran = GeneticAlgorithm.random;

    /**
     * If true, the best organism generated up to generation t is
     * placed into generation t+1 if it is not already selected in
     * generation t+1
     */
    protected boolean elitism = false;

    /**
     * An inner class for scaling fitnesses.
     */
    private static class Function {

	// any scaling function will presumably use the population's
	// minimum and maximum fitnesses to determine scaling
	public double min, max;

	public double f(double x) {
	    return x;
	}
    }

    /**
     * A function that transforms values in the range [min, max] to
     * the range [0, 1].
     */
    private static class Linear extends Function {

	public double f(double x) {
	    double range = max - min;
	    if (range == 0.0)	// all fitnesses the same, so return 1.0
		return 1.0;
	    else
		return (x - min) / (max - min);
	}
    }

    /**
     * The function used in scaling this Population's fitness values.
     */
    private Function fitness_scale = new Linear();

    /**
     * Constructs a population of the specified size; by default, elitism
     * is set to false.
     */
    public SusPopulation(int size) {
	super(size);
    }

    /**
     * Constructs a population of the specified size and elitism.
     * If elitism is true, the best organism generated up to generation
     * t is placed into generation t+1 if it is not already selected
     * in generation t+1.
     */
    public SusPopulation(int size, boolean elitism) {
	this(size);
	this.elitism = elitism;
    }

    /**
     * A method used for fitness scaling.
     */
    private void setMinMax() {
	double[] stats = getFitnessStats();
	fitness_scale.min = stats[0];
	fitness_scale.max = stats[1];
    }

    /**
     * Returns the scaled fitness of the specified Organism.
     */
    public double getScaledFitness(Organism org) {
	return fitness_scale.f(org.getFitness());
    }

    /**
     * Returns the sum of the scaled fitnesses of organisms in this
     * Population.
     */
    public double getScaledFitnessSum() {
	double sum_fitness = 0.0;
	for (int i = 0; i < storage.length; i++)
	    sum_fitness += getScaledFitness(storage[i]);
	return sum_fitness;
    }

    /**
     * Returns a new population derived from this population via
     * stochastic universal selection.  Organisms in the new population
     * are deep copies of their counterparts in this population.  A
     * deep copy of the specified incumbent organism is placed in the
     * new population if elitism is set to true.
     */
    public Population select(Organism incumbent) {

	// make sure population is properly scaled before selection
	setMinMax();

	// create a new population for the next generation
	Population p = new SusPopulation(storage.length, elitism);

	// if the incumbent is not selected and we're using elitism,
	// force the incumbent into the next generation anyway
	boolean incumbent_selected = false;

	// cumulative fitness in the population for roulette wheel size
	double sum = getScaledFitnessSum();

	// selection "markers" placed at equal increments
	double delta = sum / storage.length;

	// start somewhere within delta in the roulette wheel
	double r = ran.nextFloat();
	double location = delta * r;

	int i = 0;		// index in new generation (p)
	int j = 0;		// index in old generation (this)

	double partsum = getScaledFitness(storage[j]);

	do {
	    if (location < partsum) {
		Organism selected = storage[j];
		if (selected == incumbent)
		    incumbent_selected = true;
                p.storage[i++] = (Organism) selected.clone();
		location += delta;
	    } else {
		j++;
		partsum += getScaledFitness(storage[j]);
	    }
	} while (i < storage.length);
	
        // Elitism -- ensure incumbent makes it into the next generation
	if (elitism && !incumbent_selected)
	    p.storage[0] = (Organism) incumbent.clone();

	return p;
    }

    /**
     * Returns a string that contains the GA settings used in this
     * class.  The string representation consists of the population
     * statistics and settings for elitism.
     */
    public String getSettings() {
	return super.getSettings() +
	    "  elitism: " + elitism + "\n";
    }
}
