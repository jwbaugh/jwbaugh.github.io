/*
 * ByteArrayOrganism.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * A ByteArrayOrganism provides a common implementation for Organisms
 * that are represented as an array of genes in which each gene has a
 * maximum of 2^8 (256) possible states.  A subclass of ByteArrayOrganism
 * need implement only a constructor and the following methods:
 * <ul>
 * <li> <tt>crossover</tt>, which may be implemented in terms of the
 *      <tt>uniformCrossover</tt> and <tt>onePointCrossover</tt> methods
 *      provided,
 * <li> <tt>mutate</tt>, which may be implemented in terms of the
 *      <tt>mutate(double)</tt> method provided, and
 * <li> <tt>evaluate</tt>, which should return the fitness of the
 *      organism.
 * </ul>
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
abstract public class ByteArrayOrganism extends Organism implements Cloneable {

    /**
     * A reference to the random number generator defined in the
     * GeneticAlgorithm class (used simply as an abbreviation).
     */
    private static java.util.Random ran = GeneticAlgorithm.random;

    /**
     * An organism's chromosome: an array of genes in which each
     * gene has a maximum of 2^8 (256) possible states.
     */
    protected byte[] storage;

    /**
     * The number of possible states at each storage location, e.g.,
     * values = 2 for a binary string.
     */
    protected int values = 8;

    /**
     * Returns a deep copy of this ByteArrayOrganism.
     */
    public Object clone() {
	ByteArrayOrganism org = (ByteArrayOrganism) super.clone();
	org.storage = (byte[]) storage.clone();
	return org;
    }

    /**
     * Modifies this Organism so that it is in a random state.
     */
    public void randomize() {
	for (int i = 0; i < storage.length; i++)
	    storage[i] = (byte) ran.nextInt(values);
	unsetFitness();		// must be recomputed
    }

    /**
     * Combines this and the specified Organism (the parents) via uniform
     * crossover and overwrites them with the resulting offspring.  The
     * specified Organism must be a ByteArrayOrganism; otherwise a runtime
     * exception is thrown.
     */
    public void uniformCrossover(Organism org) {
	ByteArrayOrganism b = (ByteArrayOrganism) org;
	int size = Math.min(storage.length, b.storage.length);

	for (int i = 0; i < size; i++) {
	    if (ran.nextInt(2) == 0) {
		// swap contents of this and b
		byte temp = storage[i];
		storage[i] = b.storage[i];
		b.storage[i] = temp;
	    }
	}
	unsetFitness();		// must be recomputed
	b.unsetFitness();
    }

    /**
     * Combines this and the specified Organism (the parents) via one-point
     * crossover and overwrites them with the resulting offspring.  The
     * specified Organism must be a ByteArrayOrganism; otherwise a runtime
     * exception is thrown.
     */
    public void onePointCrossover(Organism org) {
	ByteArrayOrganism b = (ByteArrayOrganism) org;
	int size = Math.min(storage.length, b.storage.length);
	int index = ran.nextInt(size);

	for (int i = index; i < size; i++) {
	    byte temp = storage[i];	// swap contents of this and b
	    storage[i] = b.storage[i];
	    b.storage[i] = temp;
	}
	unsetFitness();		// must be recomputed
	b.unsetFitness();
    }

    /**
     * Mutates each gene in this Organism with the specified
     * probability.  If the <tt>values</tt> field is greater
     * than 2, the mutation of a particular position results
     * in a random change to a different value.
     */
    public void mutate(double mutation_probability) {
	for (int i = 0; i < storage.length; i++)
	    if (ran.nextFloat() < mutation_probability)
		storage[i] =
		    (byte) ((storage[i] + 1 + ran.nextInt(values-1)) %
			    values);
	unsetFitness();		// must be recomputed
    }
    
    /**
     * Returns a string that contains the GA settings used in this
     * class.
     */
    public String getSettings() {
	return super.getSettings() +
	    "  storage.length: " + storage.length + "\n" +
	    "  values: " + values + "\n";
    }

    /**
     * Returns a string representation of this ByteArrayOrganism.
     */
    public String toString() {
	StringBuffer s = new StringBuffer();
	s.append(super.toString());
	s.append(" < ");
	for (int i = 0; i < storage.length; i++) {
	    s.append(storage[i]);
	    s.append(" ");
	}
	s.append(">");
	return new String(s);
    }
}
