/*
 * RealOrganism.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.text.DecimalFormat;

/*
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class RealOrganism extends ByteArrayOrganism {

    private static DecimalFormat df = new DecimalFormat("0.00");

    public RealOrganism() {
	storage = new byte[30];
	values = 2;
    }

    public int maxReal() {
	return (int) Math.pow(2, storage.length) - 1;
    }

    public static double decode(byte[] b) {
	double accum = 0.0;
	double power_of_2 = 1.0;
	for (int i = 0; i < b.length; i++) {
	    accum += b[i] * power_of_2;
	    power_of_2 *= 2;
	}
	return accum;
    }

    public static byte[] encode(double x, int n) {
	int xi = (int) Math.round(x);
	byte[] b = new byte[n];
	for (int i = 0; i < b.length; i++) {
	    b[i] = (byte) (xi % 2);
	    xi /= 2;
	}
	return b;
    }

    public double zero_to_one() {
	return decode(storage) / maxReal();
    }

    public void setTo(double x) {
	storage = encode(x * maxReal(), storage.length);
    }

    public void crossover(Organism org) {
	uniformCrossover(org);
    }

    public void mutate() {
	mutate(0.008);
    }

    protected Fitness evaluate() {
	double x = zero_to_one();
	double f1 = Math.pow(Math.sin(5 * Math.PI * x), 6);
	double f2 = f1 * Math.exp(-2 * Math.log(2) *
				  Math.pow((x - 0.1) / 0.8 , 2));
	return new Fitness(f2);
    }

    // try phenotypic difference
    /*
    public double distance(Organism org) {
	return Math.abs(zero_to_one() - ((RealOrganism) org).zero_to_one());
    }
    */

    public String toString() {
	return super.toString() + " x = " + df.format(zero_to_one());
    }

    public static void main(String[] args) {

	byte[] b = encode(3, 30);
	for (int i = 0; i < b.length; i++) {
	    System.out.print(b[i] + " ");
	}
	System.out.println();

	System.out.println(decode(b));
    }
}
