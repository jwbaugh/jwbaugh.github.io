/*
 * Fitness.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.io.Serializable;
import java.text.DecimalFormat;

/**
 * A fitness is a mutable value produced when evaluating an
 * an organism.  Its role is to act as a hook for GA schemes
 * that need to manage or incorporate multiple values for
 * each fitness, such as raw fitness values or multi-objective
 * values.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class Fitness implements Cloneable, Serializable {

    private static DecimalFormat df = new DecimalFormat("0.00");

    /** The value of this Fitness object. */
    protected double value;

    /**
     * Creates a new Fitness with the specified value.
     */
    public Fitness(double value) {
	this.value = value;
    }

    /**
     * Returns a deep copy of this Fitness.  Subclasses should define
     * appropriate clone methods that may explicitly call this one.
     */
    public Object clone() {
	try {
	    return super.clone();
	} catch (CloneNotSupportedException e) {
            // this shouldn't happen because Fitness is Cloneable
	    throw new InternalError(e.toString());
	}
    }

    /**
     * Returns the value of this Fitness.
     */
    public double getValue() {
	return value;
    }

    /**
     * Sets this Fitness to the specified value.
     */
    public void setValue(double value) {
	this.value = value;
    }

    /**
     * Returns a string representation of this fitness.
     */
    public String toString() {
	return df.format(value);
    }
}
    
