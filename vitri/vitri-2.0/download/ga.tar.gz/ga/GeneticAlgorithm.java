/*
 * GeneticAlgorithm.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * This class is designed to accommodate multiple, coexisting
 * algorithmic implementations of a genetic algorithm.  Subclasses are
 * required to implement a constructor, which sets the initial
 * population, and the <tt>run(int, int)</tt> method.  To the extent
 * possible, subclasses should also update the <tt>population</tt> and
 * <tt>generation_number</tt> fields during iteration; doing so
 * enables, for instance, the use of dynamic or adaptive penalty
 * functions in organism evaluation.  They should also use the value
 * of <tt>print_level</tt> to control the amount of detail printed
 * during execution.  By design, this class is intended to be
 * <i>reentrant</i> in the sense that a genetic algorithm, say, can be
 * run within a genetic algorithm without any interference between the
 * two levels of search.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public abstract class GeneticAlgorithm {

    /**
     * A single random number generator for use throughout the
     * genetic algorithm code.  Its seed can be set with the
     * setSeed method.
     */
    public static final java.util.Random random = new java.util.Random();

    /**
     * The "current" GA population, i.e., the population corresponding to
     * the value of generation_number
     */
    protected Population population;

    /**
     * The "current" generation number (the initial population is
     * generation 0)
     */
    protected int generation_number = 0;

    /**
     * The amount of detail printed during execution (from 0 to 5), with
     * higher numbers printing more information.
     */
    protected int print_level = 2;

    /**
     * Creates a new GeneticAlgorithm with the specified initial
     * population.
     */
    protected GeneticAlgorithm(Population p) {
	population = p;
    }

    /**
     * Performs a run of this genetic algorithm, returning the fittest
     * organism after the specified number of generations.
     */
    public Organism run(int max_generations) {
	return run(max_generations, max_generations);
    }

    /**
     * Performs a run of this genetic algorithm, returning the fittest
     * organism after the specified number of generations, or after no
     * improvement is made for the specified number of generations.
     */
    public abstract Organism run(int max_generations,
				 int max_generations_wo_improvement);

    /**
     * Returns the current population of this GeneticAlgorithm.
     */
    public Population getPopulation() {
	return population;
    }

    /**
     * Returns the current generation number of this GeneticAlgorithm.
     */
    public int getGenerationNumber() {
	return generation_number;
    }

    /**
     * Returns the print level (from 0 to 5) of this GeneticAlgorithm.
     * Higher levels result in more information being printed during
     * its run.
     */
    public int getPrintLevel() {
	return print_level;
    }

    /**
     * Sets the print level (from 0 to 5) of this GeneticAlgorithm.
     * Higher levels result in more information being printed during
     * its run.
     */
    public void setPrintLevel(int level) {
	if (level < 0 || level > 5)
	    throw new RuntimeException("In setPrintLevel(int): " +
				       "level out of range (" + level +")");
	print_level = level;
    }

    /**
     * Returns a string that contains the GA settings used in this
     * class.
     */
    public String getSettings() {
	StringBuffer s = new StringBuffer();
	s.append("---- Genetic Algorithm Parameters ----\n");
	s.append("Genetic algorithm class: " + getClass().getName() + "\n");
	s.append("Print level: " + print_level + "\n");
	s.append(population.getSettings());
	s.append(population.getRandomOrganism().getSettings());
	return new String(s);
    }

    /**
     * Returns a string representation of this GeneticAlgorithm.
     */
    public String toString() {
	return getSettings();
    }
}
