/*
 * KnapsackOrganism.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * This class implements a specific Knapsack problem.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class KnapsackOrganism extends ByteArrayOrganism {

    /** The benefit of item i */
    private static final int[] benefit =
    { 1, 13, 12, 19, 1, 6, 6, 15, 8, 4, 5, 12, 11, 18, 9, 9, 12, 16, 2, 8,
      11, 3, 9, 17, 2, 16, 2, 5, 3, 17, 11, 10, 13, 18, 2, 7,13, 11, 10, 16 };

    /** The cost of item i */
    private static final int[] cost =
    { 7, 3, 5, 7, 9, 1, 18, 12, 12, 19, 1, 18, 12, 13, 16, 6, 17, 6, 15, 16,
      10, 10, 10, 6, 11, 16, 10, 5, 1, 12, 4, 19, 6, 4, 13, 1, 17, 11, 9, 11 };

    /** The number of items under consideration for the knapsack. */
    private static int size = benefit.length;
    
    /** The penalty for exceeding cost. */
    private static final int PENALTY = 4;

    /** The most available to spend (budget) */
    private static final int MAX_COST = 200;

    /** The probability that an individual gene is mutated. */
    private static final double mutation_probability = 0.008;

    /** Uses uniform crossover if true, one-point crossover otherwise. */
    private static final boolean use_uniform_crossover = true;

    /**
     * Constructs a new KnapsackOrganism whose binary encoding is
     * initialized with all zero values.
     */
    public KnapsackOrganism() {
	storage = new byte[size];
	values = 2;
    }

    /**
     * Returns the dot product of the storage field and the specified array.
     */
    public int dot(int[] a) {
	int sum = 0;
	for (int i = 0; i < storage.length; i++)
	    sum += storage[i] * a[i];
	return sum;
    }

    /**
     * Returns the fitness of this KnapsackOrganism
     */
    protected Fitness evaluate() {
	int b = dot(benefit);
	int c = dot(cost);
	return new Fitness(b - (c > MAX_COST ? PENALTY * (c - MAX_COST) : 0));
    }

    /**
     * Combines this and the specified Organism (the parents) and
     * overwrites them with the resulting offspring.
     */
    public void crossover(Organism org) {
	if (use_uniform_crossover)
	    uniformCrossover(org);
	else
	    onePointCrossover(org);
    }

    /**
     * Mutates each gene in this Organism with a specified probability.
     */
    public void mutate() {
	mutate(mutation_probability);
    }

    /**
     * Returns a string that contains the GA settings used in this
     * class.
     */
    public String getSettings() {
	return super.getSettings() +
	    "  crossover: " + (use_uniform_crossover ?
			       "uniform" : "one-point") + "\n" +
	    "  mutation_probability: " + mutation_probability + "\n";
    }

    /**
     * Returns a string representation of this KnapsackOrganism.
     */
    public String toString() {
	return super.toString() + " b = " + dot(benefit) + " c = " + dot(cost);
    }

    /**
     * Runs a simple genetic algorithm on this knapsack problem
     * using binary tournament selection.
     */
    public static void main(String[] args) {

	GeneticAlgorithm.random.setSeed(0);

	BtsPopulation pop = new BtsPopulation(100);
	Organism prototype = new KnapsackOrganism();
	pop.fill(prototype);
	pop.randomize();

	GeneticAlgorithm ga = new SimpleGA(pop);
	System.out.println(ga);
	KnapsackOrganism fittest = (KnapsackOrganism) ga.run(50);
    }
}
