/*
 * Population.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.util.*;
import java.text.DecimalFormat;

/**
 * This class provides a skeletal implementation of a population,
 * which maintains a collection of <tt>Organisms</tt>.  Operations
 * provided by <tt>Population</tt> are straightforward, and often just
 * iterate over organism instances.  For example, the <tt>mutate</tt>
 * method successively mutates each organism in the population. <p>
 *
 * Subclasses need provide only a selection policy to realize a
 * concrete population; this is accomplished by implementing the
 * abstract method <tt>select(Organism)</tt>, which creates a new
 * population from an old one using a customized selection process.
 * Note that such implementations should place organism <i>clones</i>,
 * and not the organisms themselves, into the new population.  Also,
 * to improve convergence of the search process, a clone of the
 * incumbent solution may be placed in the new population; it is given
 * as an argument to the <tt>select</tt> method.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public abstract class Population {

    private static DecimalFormat df = new DecimalFormat("0.00");

    /**
     * A reference to the random number generator defined in the
     * GeneticAlgorithm class (used simply as an abbreviation)
     */
    private static java.util.Random ran = GeneticAlgorithm.random;

    /**
     * Probability that crossover is performed: a value of 1 means that
     * no parent organisms survive into the next generation; a value of
     * 0 means that all survive
     */
    private double crossover_probability = 0.75;

    /**
     * A population's organisms: an array that contains all organisms
     * in this population.
     */
    protected Organism[] storage;

    /**
     * Creates a new, empty Population that can accommodate the specified
     * number of organisms, which must be 2 or greater.
     */
    protected Population(int size) {
	if (size < 2)
	    throw new RuntimeException("In Population(int): " +
				       "population size < 2 (" + size + ")");
	storage = new Organism[size];
    }

    /**
     * Places clones of the specified organism throughout this Population.
     */
    public void fill(Organism prototype) {
	for (int i = 0; i < storage.length; i++)
	    storage[i] = (Organism) prototype.clone();
    }

    /**
     * Randomizes every organism in this Population.
     */
    public void randomize() {
        for (int i = 0; i < storage.length; i++)
            storage[i].randomize();
    }

    /**
     * Returns an iterator over the organisms in this Population.
     */
    public Iterator iterator() {
	return Arrays.asList(storage).iterator();
    }

    /**
     * Returns the number of organisms accommodated by this Population.
     */
    public int size() {
	return storage.length;
    }

    /**
     * Sets the probability used during this Population's <tt>crossover</tt>
     * method that a given pair of organisms will be overwritten
     * by their offspring, i.e., by the result of performing crossover
     * on the pair of organisms.  The specified probability must
     * satisfy 0 <= p <= 1.
     */
    public void setCrossoverProbability(double p) {
	if (p < 0 || p > 1)
	    throw new RuntimeException("In setCrossoverProbability(double): " +
				       "probability out of range (" +
				       crossover_probability + ")");
	crossover_probability = p;
    }

    /**
     * Returns the probability used during this Population's <tt>crossover</tt>
     * method that a given pair of organisms will be overwritten
     * by their offspring, i.e., by the result of performing crossover
     * on the pair of organisms.
     */
    public double getCrossoverProbability() {
	return crossover_probability;
    }

    /**
     * Returns a new population derived from this population via
     * an implemented selection process.  Organisms in the new
     * population must be deep copies of their counterparts
     * in this population.  A deep copy of the specified incumbent
     * organism may be placed in the new population through an
     * elitism policy.
     */
    public abstract Population select(Organism incumbent);

    /**
     * Performs crossover on this Population by taking its organisms
     * in pairs and applying the organisms' <tt>crossover</tt> method with
     * a probability that may be set and returned by this Population's
     * <tt>setCrossoverProbability</tt> and <tt>getCrossoverProbability</tt>
     * methods, respectively.
     */
    public void crossover() {
	for (int i = 0; i < (storage.length - 1); i += 2) {
	    if (ran.nextFloat() < crossover_probability)
		storage[i].crossover(storage[i+1]);
	}
    }
  
    /**
     * Performs mutation on each of this Population's organisms.
     */
    public void mutate() {
	for (int i = 0; i < storage.length; i++)
	    storage[i].mutate();
    }

    /**
     * Finds and returns a random organism from this Population.
     */
    public Organism getRandomOrganism() {
	return storage[ran.nextInt(storage.length)];
    }
    
    /**
     * Finds and returns the organism in this Population with the
     * greatest fitness value.
     */
    public Organism getFittestOrganism() {
        int index_of_fittest = 0;

        for (int i = 1; i < storage.length; i++)
            if (storage[i].getFitness() >
                storage[index_of_fittest].getFitness())
                index_of_fittest = i;
        return storage[index_of_fittest];
    }

    /**
     * Calculates and returns the average fitness of the organisms
     * in this Population.
     */
    public double getAvgFitness() {
        double sum = 0;

        for (int i = 0; i < storage.length; i++)
            sum += storage[i].getFitness();
        return sum / storage.length; 
    }

    /**
     * Calculates and returns the following fitness statistics of
     * the organisms in this Population: minimum, maximum, average,
     * and sum.
     */
    public double[] getFitnessStats() {
        double min, max, sum;
	min = max = sum = storage[0].getFitness();

        for (int i = 1; i < storage.length; i++) {
	    double fitness = storage[i].getFitness();
	    min = Math.min(fitness, min);
	    max = Math.max(fitness, max);
            sum += fitness;
	}

	double[] stats = {min, max, sum/storage.length, sum};
        return stats;
    }

    /**
     * Returns a string that contains the GA settings used in this
     * class.
     */
    public String getSettings() {
	return "Population class: " + getClass().getName() + "\n" +
	    "  size: " + storage.length + "\n" +
	    "  crossover_probability: " + crossover_probability + "\n";
    }

    /**
     * Returns a string representation of this population.  The string
     * representation consists of the population statistics, including
     * the fittest organism and the minimum, maximum, and average
     * fitnesses of the population as a whole.
     */
    public String toString() {
	double[] stats = getFitnessStats();

	return "Fittest in current generation:\n  " + getFittestOrganism() +
	    "\nMin/Max/Avg fitness: " + df.format(stats[0]) + "/" +
	    df.format(stats[1]) + "/" + df.format(stats[2]);
    }
}
