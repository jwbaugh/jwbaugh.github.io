/*
 * Organism.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

import java.io.Serializable;

/**
 * This class provides a skeletal implementation of an organism.
 * A key consideration in its design is that the contractual
 * obligations imposed on an organism's realization focus on the
 * organism's behavior and not on its implementation.  That is, an
 * organism's encoding, e.g., 0/1 versus real-valued encodings, is
 * hidden, allowing any encoding approach to be taken and used within
 * this framework.  Subclasses need implement only the following
 * methods: <tt>randomize</tt>, <tt>crossover</tt>, <tt>mutate</tt>,
 * and <tt>evaluate</tt>. <p>
 *
 * Because fitness evaluation can be costly in some applications, an
 * organism is designed so that evaluation need happen only once, which
 * is accomplished by caching evaluation results.  This policy, however,
 * places responsibility on an organism's storage-modifying operators to
 * clear its cache, typically by calling the <tt>unsetFitness</tt> method.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public abstract class Organism implements Cloneable, Serializable {

    /**
     * The number of fitness evaluations performed over all Organisms
     */
    private static int evaluation_count = 0;

    /**
     * Caches the fitness of an Organism: a null value implies that
     * the fitness has not been calculated and must be determined
     * by calling evaluate() (see getFitness() below)
     */
    protected transient Fitness fitness = null;

    /**
     * Returns a deep copy of this Organism.  Subclasses should define
     * appropriate clone methods that may explicitly call this one.
     */
    protected Object clone() {
        try {
	    Organism org = (Organism) super.clone();
	    if (fitness != null)
		org.fitness = (Fitness) fitness.clone();
	    return org;
        } catch (CloneNotSupportedException e) {
            // this shouldn't happen because Organism is Cloneable
	    throw new InternalError(e.toString());
        }
    }

    /**
     * Modifies this Organism so that it is in a random state.
     */
    public abstract void randomize();

    /**
     * Combines this and the specified organism (the parents) to produce
     * two new offspring; parents are overwritten with their offspring.
     */
    public abstract void crossover(Organism org);

    /**
     * Mutates this Organism.
     */
    public abstract void mutate();
    
    /**
     * Returns the fitness of this Organism; this method should not
     * be called by any method other than Organism.getFitnessObject.
     */
    protected abstract Fitness evaluate();

    /**
     * Returns the cumulative number of evaluations performed over all
     * instances of Organisms.
     */
    public static int getEvaluationCount() {
	return evaluation_count;
    }

    /**
     * Resets to zero the counter that tracks the cumulative number
     * of evaluations performed over all instances of Organisms.
     */
    public static int resetEvaluationCount() {
	return evaluation_count = 0;
    }

    /**
     * Forces re-evaluation of an organism to determine fitness.
     */
    public void unsetFitness() {
	fitness = null;
    }

    /**
     * Returns the fitness value of this Organism.
     */
    public final double getFitness() {
	return getFitnessObject().getValue();
    }

    /**
     * Returns the fitness object of this Organism.
     */
    public Fitness getFitnessObject() {
	if (fitness == null) {
	    fitness = evaluate();
	    evaluation_count++;
	}
	return fitness;
    }

    /**
     * Sets the fitness object of this Organism to the specified value;
     * this method is typically needed only when an Organism is evaluated
     * remotely.
     */
    public void setFitnessObject(Fitness f) {
	fitness = f;
	evaluation_count++;	// update since evaluation is non-local 
    }

    /**
     * Returns a string that contains the GA settings used in this
     * class.
     */
    public String getSettings() {
	return "Organism class: " + getClass().getName() + "\n";
    }

    /**
     * Returns a string representation of this organism.  The string
     * representation consists of the organism's fitness.  Subclasses
     * of an organism are expected to extend this behavior.
     */
    public String toString() {
	return "[" + fitness + "]";
    }
}
