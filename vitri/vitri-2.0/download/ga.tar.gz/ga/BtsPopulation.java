/*
 * BtsPopulation.java
 *
 * Copyright (C) 2003 John Baugh.   All rights reserved.
 *
 * This file is part of Vitri.
 *
 * Vitri is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * This class implements probabilistic binary tournament selection.
 *
 * @author John Baugh (john.baugh@ncsu.edu)
 * @version 2.0
 */
public class BtsPopulation extends Population {

    /**
     * A reference to the random number generator defined in the
     * GeneticAlgorithm class (used simply as an abbreviation)
     */
    private static java.util.Random ran = GeneticAlgorithm.random;

    /**
     * If true, the best organism generated up to generation t is
     * placed into generation t+1 if it is not already selected in
     * generation t+1.
     */
    private boolean elitism = false;

    /**
     * Probability that the fittest organism "wins" when competing
     * in tournament selection.
     */
    private double select_fittest_probability = 0.75;

    /**
     * Constructs a population of the specified size; by default, elitism
     * is set to false, and select-fittest probability is set to 0.75.
     */
    public BtsPopulation(int size) {
	super(size);
    }

    /**
     * Constructs a population of the specified size and elitism;
     * by default, select-fittest probability is set to 0.75.  If
     * elitism is true, the best organism generated up to generation
     * t is placed into generation t+1 if it is not already selected
     * in generation t+1.
     */
    public BtsPopulation(int size, boolean elitism) {
	this(size);
	this.elitism = elitism;
    }

    /**
     * Sets whether or not elitism is used in this population; if the
     * specified value is true, the best organism generated up to
     * generation t is placed into generation t+1 if it is not already
     * selected in generation t+1.
     */
    public void setElitism(boolean b) {
	elitism = b;
    }

    /**
     * Returns the elitism setting used in this population; if the
     * specified value is true, the best organism generated up to
     * generation t is placed into generation t+1 if it is not already
     * selected in generation t+1.
     */
    public boolean getElitism() {
	return elitism;
    }

    /**
     * Sets the probability in this population that the fittest
     * organism "wins" when competing in tournament selection.
     */
    public void setSelectFittestProbability(double p) {
	if (p < 0 || p > 1)
	    throw new RuntimeException("In setSelectFittestProbability(double): " +
				       "probability out of range (" +
				       select_fittest_probability + ")");
	select_fittest_probability = p;
    }

    /**
     * Returns the probability in this population that the fittest
     * organism "wins" when competing in tournament selection.
     */
    public double getSelectFittestProbability() {
	return select_fittest_probability;
    }

    /**
     * Returns a new population derived from this population via
     * probabilistic binary tournament selection.  Organisms in
     * the new population are deep copies of their counterparts
     * in this population.  A deep copy of the specified incumbent
     * organism is placed in the new population if elitism is
     * set to true.  When two organisms compete, the fittest "wins"
     * with a probability specified by the method
     * <tt>setSelectFittestProbability(double)</tt>.
     */
    public Population select(Organism incumbent) {

	//create a new population for the next generation
	BtsPopulation p = new BtsPopulation(storage.length, elitism);
	p.select_fittest_probability = select_fittest_probability;

	// if the incumbent is not selected and we're using elitism,
	// force the incumbent into the next generation anyway
	boolean incumbent_selected = false;

        for (int i = 0; i < p.storage.length; i++) {
            Organism o1 = getRandomOrganism();
            Organism o2 = getRandomOrganism();

            if ( (ran.nextFloat() < select_fittest_probability) ==
                 (o1.getFitness() > o2.getFitness()) )
                p.storage[i] = o1;
            else
                p.storage[i] = o2;

	    if (p.storage[i] == incumbent)
		incumbent_selected = true;

	    // make sure we have a fresh copy, instead of the original
	    p.storage[i] = (Organism) p.storage[i].clone();
        }

        // Elitism -- ensure incumbent makes it into the next generation
	if (elitism && !incumbent_selected)
	    p.storage[0] = (Organism) incumbent.clone();

	return p;
    }

    /**
     * Returns a string that contains the GA settings used in this
     * class.  The string representation consists of the population
     * statistics and settings for elitism and the select-fittest
     * probability.
     */
    public String getSettings() {
	return super.getSettings() +
	    "  elitism: " + elitism + "\n" +
	    "  select_fittest_probability: " + select_fittest_probability + "\n";
    }
}
